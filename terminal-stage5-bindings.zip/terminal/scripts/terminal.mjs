/* =============================================================
   TERMINAL — generic in-world computer UI engine
   Stage 4 (crew): collections + parameterized navigation +
   crew-roster / dossier render types.

   Navigation targets come in two forms:
     "missions"        -> a standalone screen (journal with id)
     "crew/matthews"   -> a collection member (collection "crew",
                          member id "matthews") rendered as its
                          member render type (e.g. dossier)

   NAMESPACE: "terminal". Theme is a configurable class.

   ⚠ VERSION-SENSITIVE: foundry.applications.api access path, window
   options, ApplicationV2 actions, handlebars.loadTemplates. 13.351.
   ============================================================= */

import {
  loadScreen, loadCollection, loadMember
} from "./data.mjs";
import { requestWrite } from "./sockets.mjs";
import { debugTime } from "./gametime.mjs";
import { resolveSelfAuthor } from "./bindings.mjs";
import "./config.mjs";
import "./controls.mjs";
import "./sockets.mjs";
import "./bindings.mjs";

const MODULE_ID = "terminal";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

/* render-type -> partial. Add a layout = add a partial + an entry. */
const RENDER_TEMPLATES = {
  hub:            `modules/${MODULE_ID}/templates/render/hub.hbs`,
  "crew-roster":  `modules/${MODULE_ID}/templates/render/crew-roster.hbs`,
  dossier:        `modules/${MODULE_ID}/templates/render/dossier.hbs`,
  "mission-board":`modules/${MODULE_ID}/templates/render/mission-board.hbs`,
  "mission":      `modules/${MODULE_ID}/templates/render/mission.hbs`,
  "blackbox":     `modules/${MODULE_ID}/templates/render/blackbox.hbs`,
  "feed":         `modules/${MODULE_ID}/templates/render/feed.hbs`,
  "request-board":`modules/${MODULE_ID}/templates/render/request-board.hbs`
};

class TerminalApp extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "terminal-app",
    tag: "div",
    classes: ["terminal-app"],
    window: { title: "TERMINAL", frame: true, positioned: true, resizable: true },
    position: { width: 720, height: 640, left: 200, top: 100 },
    actions: {
      navigate: TerminalApp.#onNavigate,
      back: TerminalApp.#onBack,
      home: TerminalApp.#onHome,
      setStatus: TerminalApp.#onSetStatus,
      toggleLike: TerminalApp.#onToggleLike,
      addComment: TerminalApp.#onAddComment
    }
  };

  static PARTS = {
    body: { template: `modules/${MODULE_ID}/templates/shell.hbs` }
  };

  /* Current target: a string like "main" or "crew/matthews". */
  target = null;
  #history = [];

  get currentTarget() {
    return this.target ?? game.settings.get(MODULE_ID, "homeScreenId");
  }

  /* Parse a target into { collection, id }.
     "crew/matthews" -> { collection: "crew", id: "matthews" }
     "missions"      -> { collection: null,  id: "missions"  } */
  static parseTarget(target) {
    if (target.includes("/")) {
      const [collection, id] = target.split("/");
      return { collection, id };
    }
    return { collection: null, id: target };
  }

  async goTo(target, { pushHistory = true } = {}) {
    if (pushHistory && this.currentTarget) this.#history.push(this.currentTarget);
    this.target = target;
    await this.render(false);
  }
  async goBack() {
    if (!this.#history.length) return;
    this.target = this.#history.pop();
    await this.render(false);
  }
  async goHome() {
    this.#history = [];
    this.target = null;
    await this.render(false);
  }

  clearHistory() { this.#history = []; }

  static #onNavigate(event, target) {
    const t = target?.dataset?.target;
    if (t) this.goTo(t);
  }
  static #onBack() { this.goBack(); }
  static #onHome() { this.goHome(); }

  /* Click a request's status -> popup of the board's valid statuses ->
     request the write (player: via GM socket; GM: directly). The board
     screen id and the request id ride on the clicked element. Valid
     statuses come from the current screen's sections (data-driven). */
  static async #onSetStatus(event, target) {
    event?.stopPropagation?.(); // don't trigger the row/card navigation
    const requestId = target?.dataset?.requestId;
    const screenId = target?.dataset?.screenId;
    if (!requestId || !screenId) {
      console.warn(`${MODULE_ID} | setStatus: missing requestId/screenId`, { requestId, screenId });
      return;
    }

    // Gather valid statuses from the current screen's sections.
    const res = loadScreen(screenId);
    const sections = res.ok ? (res.data.sections ?? []) : [];
    const statuses = [...new Set(sections.flatMap(s => s.statuses ?? []))];
    if (!statuses.length) {
      console.warn(`${MODULE_ID} | setStatus: no statuses resolved (screen "${screenId}")`);
      return;
    }

    const isGM = game.user.isGM;
    const { DialogV2 } = foundry.applications.api;

    const statusOptions = statuses
      .map(s => `<option value="${s}">${s}</option>`).join("");
    const gmNameField = isGM
      ? `<div class="form-group"><label>Responder name (optional)</label>
           <input type="text" name="by" placeholder="e.g. an NPC name; blank = you" /></div>`
      : "";

    const content = `
      <div class="form-group">
        <label>New status</label>
        <select name="status">${statusOptions}</select>
      </div>
      ${gmNameField}`;

    const result = await DialogV2.prompt({
      window: { title: "Update Status" },
      content,
      ok: {
        label: "Update",
        callback: (_ev, button) => {
          const form = button.form;
          return {
            status: form.elements.status.value,
            by: form.elements.by?.value?.trim() || null
          };
        }
      }
    }).catch(() => null);

    if (!result) return;

    // Determine the attribution name to send:
    // - GM: use the typed name, or null (blank -> no name stored).
    // - Player: their character name (fallback handled GM-side).
    const by = game.user.isGM
      ? (result.by ?? null)
      : (game.user.character?.name ?? game.user.name);

    await requestWrite({
      action: "setRequestStatus",
      screenId,
      requestId,
      status: result.status,
      by
    });
  }

  /* Crew picker for GM attribution. Returns { id, name } of the chosen
     crew member, or null if cancelled. Populated from the crew
     collection so NPC likes/comments stay link-correct. */
  static async #pickCrewMember(title, extraFieldHtml = "") {
    const members = loadCollection("crew")
      .map(m => ({ id: m.id, name: m.data?.name ?? m.id }))
      .sort((a, b) => a.name.localeCompare(b.name));
    if (!members.length) {
      ui.notifications?.warn("Terminal: no crew members found to attribute to.");
      return null;
    }
    const { DialogV2 } = foundry.applications.api;
    const options = members.map(m => `<option value="${m.id}">${m.name}</option>`).join("");
    const content = `
      <div class="form-group">
        <label>As crew member</label>
        <select name="member">${options}</select>
      </div>
      ${extraFieldHtml}`;
    return DialogV2.prompt({
      window: { title },
      content,
      ok: {
        label: "Confirm",
        callback: (_ev, button) => {
          const form = button.form;
          const id = form.elements.member.value;
          const name = members.find(m => m.id === id)?.name ?? id;
          const body = form.elements.body?.value?.trim() ?? null;
          return { id, name, body };
        }
      }
    }).catch(() => null);
  }

  /* Like control. Player: toggles their character name. GM: crew
     picker -> toggles that NPC's name. */
  static async #onToggleLike(event, target) {
    event?.stopPropagation?.();
    const postId = target?.dataset?.postId;
    const screenId = target?.dataset?.screenId;
    if (!postId || !screenId) return;

    let name;
    if (game.user.isGM) {
      const picked = await TerminalApp.#pickCrewMember("Like as…");
      if (!picked) return;
      name = picked.name;
    } else {
      name = resolveSelfAuthor().author;
    }

    await requestWrite({ action: "toggleLike", screenId, postId, name });
  }

  /* Reply control. Player: body input, authored as their BOUND crew
     member (name + authorId) if a binding exists, else their character/
     user name with no link. GM: crew picker + body, authored as the
     chosen NPC (authorId link-correct). */
  static async #onAddComment(event, target) {
    event?.stopPropagation?.();
    const postId = target?.dataset?.postId;
    const screenId = target?.dataset?.screenId;
    if (!postId || !screenId) return;

    const { DialogV2 } = foundry.applications.api;
    const bodyField = `
      <div class="form-group">
        <label>Comment</label>
        <textarea name="body" rows="3" placeholder="Write a reply…"></textarea>
      </div>`;

    let author, authorId = null, body;

    if (game.user.isGM) {
      const picked = await TerminalApp.#pickCrewMember("Reply as…", bodyField);
      if (!picked || !picked.body) return;
      author = picked.name;
      authorId = picked.id;     // link-correct: crew member id
      body = picked.body;
    } else {
      const result = await DialogV2.prompt({
        window: { title: "Reply" },
        content: bodyField,
        ok: {
          label: "Post",
          callback: (_ev, button) => ({ body: button.form.elements.body.value.trim() })
        }
      }).catch(() => null);
      if (!result || !result.body) return;
      const self = resolveSelfAuthor();
      author = self.author;
      authorId = self.authorId; // set if the player is bound to a crew member
      body = result.body;
    }

    await requestWrite({ action: "addComment", screenId, postId, author, authorId, body });
  }

  async _prepareContext(_options) {
    const themeClass = game.settings.get(MODULE_ID, "themeClass");
    const target = this.currentTarget;
    const { collection, id } = TerminalApp.parseTarget(target);
    const homeId = game.settings.get(MODULE_ID, "homeScreenId");

    const base = {
      themeClass,
      canGoBack: this.#history.length > 0,
      isHome: target === homeId
    };

    /* Collection member target (e.g. crew/matthews, missions/dark-horizon):
       load that member, render with its own render type. For members
       that participate in parent/child relations (missions), derive the
       parent's display name and the child list from the collection (one
       in-memory filter over the already-loaded set). */
    if (collection) {
      const res = loadMember(collection, id);
      if (!res.ok) return { ...base, error: res.error };
      const screen = res.data;
      const renderType = screen.render ?? null;
      const renderTemplate = RENDER_TEMPLATES[renderType] ?? null;

      let parent = null;
      let children = null;
      if (screen.parent || renderType === "mission") {
        const all = loadCollection(collection)
          .map(m => ({ id: m.id, collection, ...m.data }));
        // children: anyone claiming THIS member as their parent
        children = all
          .filter(m => m.parent === id)
          .map(m => ({ target: `${collection}/${m.id}`, name: m.name ?? m.title ?? m.id, status: m.status }));
        // parent: resolve this member's declared parent for a display name
        if (screen.parent) {
          const p = all.find(m => m.id === screen.parent);
          parent = {
            target: `${collection}/${screen.parent}`,
            name: p ? (p.name ?? p.title ?? screen.parent) : screen.parent
          };
        }
      }

      return {
        ...base,
        error: null,
        screen,
        member: { collection, id },
        parent,
        children: (children && children.length) ? children : null,
        renderType,
        renderTemplate,
        unknownRender: !renderTemplate
      };
    }

    /* Standalone screen target. */
    const res = loadScreen(id);
    if (!res.ok) return { ...base, error: res.error };
    const screen = res.data;
    const renderType = screen.render ?? "hub";
    const renderTemplate = RENDER_TEMPLATES[renderType] ?? null;

    /* If this screen draws from a collection, load + structure its
       members for the partial. Roster groups by department; board
       groups by status-section. Both produce ordered groups the
       partial just renders. */
    let groups = null;
    if (screen.collection) {
      const members = loadCollection(screen.collection)
        .map(m => ({ id: m.id, collection: screen.collection, ...m.data }));

      if (renderType === "mission-board") {
        groups = TerminalApp.#groupByStatus(members, screen.sections ?? []);
      } else {
        groups = TerminalApp.#groupRoster(members, screen.departments ?? []);
      }
    }

    /* Black box: derive the "current" entry (flagged, else last) and
       build it as labeled fields for the callout. */
    let blackbox = null;
    if (renderType === "blackbox") {
      blackbox = TerminalApp.#prepBlackbox(screen);
    }

    /* Feed: compose the like-line string per post and resolve author
       link targets, so the template stays declarative. */
    let feed = null;
    if (renderType === "feed") {
      feed = TerminalApp.#prepFeed(screen, id);
    }

    /* Request board (requisitions / crew requests): group the screen's
       requests array into declared status-sections, date descending. */
    let requestBoard = null;
    if (renderType === "request-board") {
      requestBoard = TerminalApp.#prepRequestBoard(screen, id);
    }

    return {
      ...base,
      error: null,
      screen,
      groups,
      blackbox,
      feed,
      requestBoard,
      renderType,
      renderTemplate,
      unknownRender: !renderTemplate
    };
  }

  async _preFirstRender(context, options) {
    await super._preFirstRender?.(context, options);
    const hb = foundry.applications.handlebars;
    // Load render partials (used via dynamic lookup in shell.hbs).
    await hb.loadTemplates(Object.values(RENDER_TEMPLATES));
    // Register the shared status-flag partial under a stable name.
    await hb.loadTemplates({
      terminalStatusFlag: `modules/${MODULE_ID}/templates/partials/status-flag.hbs`
    });
  }

  /* Sortable key from a date string. Handles ISO ("2186-10-28") and
     short forms ("28 Oct", "28 October 2186"). Short forms without a
     year are parsed against a fixed reference year so month/day order
     is consistent within a board. Unparseable -> -Infinity (sorts last
     in descending). */
  static #dateSortKey(raw) {
    if (!raw) return -Infinity;
    let t = Date.parse(raw);
    if (!Number.isNaN(t)) return t;
    // try "<day> <Mon>" by appending a reference year
    t = Date.parse(`${raw} 2186`);
    return Number.isNaN(t) ? -Infinity : t;
  }

  /* Group the screen's requests array into the declared status-sections
     (same section model as the mission board), date descending within
     each. Unmatched statuses go to a fallback "OTHER" section. */
  static #prepRequestBoard(screen, screenId) {
    const requests = Array.isArray(screen.requests) ? screen.requests : [];
    const sections = Array.isArray(screen.sections) ? screen.sections : [];
    const cardClass = screen.cardClass ?? ""; // e.g. "req-mission" for crew requests

    const byDateDesc = (a, b) =>
      TerminalApp.#dateSortKey(b.date) - TerminalApp.#dateSortKey(a.date) ||
      String(a.title ?? "").localeCompare(String(b.title ?? ""));

    const decorate = (r, dim) => ({ ...r, cardClass, dim, screenId });
    const claimed = new Set();
    const groups = [];

    for (const sec of sections) {
      const statuses = new Set(sec.statuses ?? []);
      const matched = requests.filter(r => statuses.has(r.status));
      matched.forEach(r => claimed.add(r));
      groups.push({
        name: sec.name,
        dim: sec.dim === true,
        requests: matched.map(r => decorate(r, sec.dim === true)).sort(byDateDesc)
      });
    }

    const leftover = requests.filter(r => !claimed.has(r));
    if (leftover.length) {
      groups.push({
        name: "OTHER",
        dim: false,
        requests: leftover.map(r => decorate(r, false)).sort(byDateDesc)
      });
    }

    return { groups };
  }

  /* Number of liker names shown before collapsing to "and X others". */
  static LIKE_NAMES_SHOWN = 3;

  /* Compose a human like-line from an array of names:
       []                      -> ""             (no like line)
       [A]                     -> "A"
       [A,B]                   -> "A and B"
       [A,B,C]                 -> "A, B and C"
       [A,B,C,D]               -> "A, B, C and 1 other"
       [A,B,C,D,E]             -> "A, B, C and 2 others"
     Shows up to LIKE_NAMES_SHOWN names; remainder -> "and X other(s)". */
  static #likeLine(likes) {
    const names = Array.isArray(likes) ? likes.filter(Boolean) : [];
    if (!names.length) return "";
    const N = TerminalApp.LIKE_NAMES_SHOWN;
    const shown = names.slice(0, N);
    const others = names.length - shown.length;

    if (others > 0) {
      return `${shown.join(", ")} and ${others} other${others === 1 ? "" : "s"}`;
    }
    // others <= 0: join all shown with commas + "and" before the last.
    if (shown.length === 1) return shown[0];
    return `${shown.slice(0, -1).join(", ")} and ${shown[shown.length - 1]}`;
  }

  /* Build feed render data: per-post composed like-line + like count. */
  static #prepFeed(screen, screenId) {
    const posts = Array.isArray(screen.posts) ? screen.posts : [];
    const out = posts.map(p => ({
      ...p,
      screenId,
      likeLine: TerminalApp.#likeLine(p.likes),
      likeCount: Array.isArray(p.likes) ? p.likes.length : 0
    }));
    return { posts: out };
  }

  /* Build black-box render data from a blackbox screen.
     - columns: ordered column names (screen.columns, else union of
       keys across the log).
     - currentFields: the current entry as labeled {label,value} pairs
       for the callout (all columns). current = entry flagged
       current:true, else the LAST entry.
     - rows: every entry as { cells:[...], current:bool } aligned to
       columns, so the table highlights the current row. */
  static #prepBlackbox(screen) {
    const log = Array.isArray(screen.log) ? screen.log : [];
    let columns = Array.isArray(screen.columns) ? screen.columns.slice() : [];
    if (!columns.length) {
      const seen = new Set();
      for (const e of log) for (const k of Object.keys(e)) {
        if (k !== "current" && !seen.has(k)) { seen.add(k); columns.push(k); }
      }
    }

    let currentIdx = log.findIndex(e => e.current === true);
    if (currentIdx === -1) currentIdx = log.length - 1;

    const rows = log.map((e, i) => ({
      cells: columns.map(c => e[c] ?? ""),
      current: i === currentIdx
    }));

    const currentEntry = log[currentIdx] ?? null;
    const currentFields = currentEntry
      ? columns.map(c => ({ label: c, value: currentEntry[c] ?? "" }))
      : [];

    return { columns, rows, currentFields, hasCurrent: !!currentEntry };
  }

  /* Group mission members into ordered status-sections defined on the
     board screen. Each section: { name, statuses: [...], archive? }.
     Within a section, sort by date descending (missing dates last).
     Missions whose status isn't in any section are appended to a
     fallback "OTHER" section so nothing vanishes. */
  static #groupByStatus(members, sections) {
    const dateKey = (m) => {
      const raw = m.date ?? m.issueDate ?? null;
      if (!raw) return -Infinity;
      const t = Date.parse(raw);
      return Number.isNaN(t) ? -Infinity : t;
    };
    const byDateDesc = (a, b) => dateKey(b) - dateKey(a) ||
      String(a.name ?? a.title ?? "").localeCompare(String(b.name ?? b.title ?? ""));

    const claimed = new Set();
    const out = [];

    for (const sec of sections) {
      const statuses = new Set(sec.statuses ?? []);
      const inSection = members.filter(m => statuses.has(m.status));
      inSection.forEach(m => claimed.add(m.id));
      out.push({
        name: sec.name,
        archive: sec.archive === true,
        members: inSection.sort(byDateDesc).map(TerminalApp.#missionRow)
      });
    }

    const leftover = members.filter(m => !claimed.has(m.id));
    if (leftover.length) {
      out.push({
        name: "OTHER",
        archive: false,
        members: leftover.sort(byDateDesc).map(TerminalApp.#missionRow)
      });
    }
    return out;
  }

  /* Shape a mission into the row fields the board partial renders.
     `date` column shows the human issueDate. `location` column shows
     the short flat `locationLabel` (since the detail `location` is now
     a structured object); falls back to system/planet if no label. */
  static #missionRow(m) {
    let loc = m.locationLabel ?? "";
    if (!loc && m.location && typeof m.location === "object") {
      loc = [m.location.planet, m.location.system].filter(Boolean).join(" — ");
    } else if (!loc && typeof m.location === "string") {
      loc = m.location;
    }
    return {
      target: `${m.collection}/${m.id}`,
      name: m.name ?? m.title ?? m.id,
      status: m.status,
      date: m.issueDate ?? m.date ?? "",
      location: loc,
      reward: m.reward ?? ""
    };
  }

  /* Group roster members into the ordered department structure the
     roster screen defines. Each department entry in screen.departments
     is either a string (no subgroups) or { name, subgroups: [...] }.
     Returns an ordered array of:
       { name, members: [...], subgroups: [{ name, members: [...] }] }
     Members sort by their numeric `sort` (then name). Unknown
     departments (present on a member but not in the order list) are
     appended at the end so nobody silently vanishes. */
  static #groupRoster(members, departmentOrder) {
    const byName = (a, b) =>
      (a.sort ?? 999) - (b.sort ?? 999) || String(a.name).localeCompare(String(b.name));

    // Normalize the department order into {name, subgroups[]} entries.
    const order = departmentOrder.map(d =>
      typeof d === "string" ? { name: d, subgroups: [] } : { name: d.name, subgroups: d.subgroups ?? [] }
    );
    const known = new Set(order.map(d => d.name));

    // Bucket members by department.
    const byDept = new Map();
    for (const m of members) {
      const dept = m.department ?? "Unassigned";
      if (!byDept.has(dept)) byDept.set(dept, []);
      byDept.get(dept).push(m);
    }

    // Append any departments that members reference but the order omits.
    for (const dept of byDept.keys()) {
      if (!known.has(dept)) order.push({ name: dept, subgroups: [] });
    }

    // Build the ordered structure.
    return order
      .filter(d => byDept.has(d.name))
      .map(d => {
        const all = byDept.get(d.name);
        const subgroups = [];
        const direct = [];
        const subSet = new Set(d.subgroups);

        for (const m of all) {
          if (m.subgroup && subSet.has(m.subgroup)) continue; // handled below
          if (m.subgroup && !subSet.has(m.subgroup)) {
            // member declares a subgroup not listed in order: treat as ad-hoc subgroup
            continue;
          }
          direct.push(m);
        }

        // Ordered, declared subgroups first.
        for (const sgName of d.subgroups) {
          const sgMembers = all.filter(m => m.subgroup === sgName).sort(byName);
          if (sgMembers.length) subgroups.push({ name: sgName, members: sgMembers });
        }
        // Any ad-hoc subgroups (declared on members, not in order).
        const adHoc = new Set(
          all.filter(m => m.subgroup && !subSet.has(m.subgroup)).map(m => m.subgroup)
        );
        for (const sgName of adHoc) {
          const sgMembers = all.filter(m => m.subgroup === sgName).sort(byName);
          subgroups.push({ name: sgName, members: sgMembers });
        }

        return { name: d.name, members: direct.sort(byName), subgroups };
      });
  }
}

/* ---- Module API ---- */
function buildApi() {
  let instance = null;
  const api = {
    open(target = null) {
      if (!instance) instance = new TerminalApp();
      // Default to home each open: reset target + history unless an
      // explicit target was requested.
      if (target) {
        instance.target = target;
      } else {
        instance.target = null;
        instance.clearHistory();
      }
      instance.render(true);
      return instance;
    },
    close() { if (instance?.rendered) instance.close(); },
    toggle() { if (instance?.rendered) instance.close(); else api.open(); },
    goTo(target) { api.open(); instance.goTo(target); },
    debugTime,
    get app() { return instance; }
  };
  return api;
}

/* ---- Lifecycle ---- */
Hooks.once("init", () => {
  console.log(`${MODULE_ID} | init`);

  /* Handlebars helper: lowercase (used for status -> flag class). */
  Handlebars.registerHelper("lower", (s) => String(s ?? "").toLowerCase());

  /* Handlebars helper: equality (used for select option selected state). */
  Handlebars.registerHelper("eq", (a, b) => a === b);

  game.settings.register(MODULE_ID, "themeClass", {
    name: "Theme Class",
    hint: "CSS class for the active terminal theme (e.g. 'me-terminal').",
    scope: "world", config: true, type: String, default: "me-terminal"
  });
  game.settings.register(MODULE_ID, "homeScreenId", {
    name: "Home Screen ID",
    hint: "The screen id the terminal opens to.",
    scope: "world", config: true, type: String, default: "main"
  });
});

Hooks.once("ready", () => {
  const mod = game.modules.get(MODULE_ID);
  mod.api = buildApi();
  console.log(`${MODULE_ID} | ready`);
});
